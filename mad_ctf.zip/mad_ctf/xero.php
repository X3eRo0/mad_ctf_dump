<?php
$output = shell_exec("cat /bin/.secret.flag");
echo "<pre>$output</pre>";
?>