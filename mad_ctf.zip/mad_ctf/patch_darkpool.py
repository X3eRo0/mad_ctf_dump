from pwn import *

elf = ELF("serverbin")

elf.asm(0x400FAC, "mov esi, 0x78")
elf.asm(0x400C57, "mov esi, 0x3c")
puts = elf.plt['puts']
elf.asm(0x400CAD, "call %s" % hex(puts))

elf.save("asdasdasdasd")