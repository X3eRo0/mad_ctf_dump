<?php
$output = shell_exec("grep -oi 'I.\{30\}=' -R /var/www/html/ | grep I | grep =");
echo "<pre>$output</pre>";
?>