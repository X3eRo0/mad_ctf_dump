<?php 
require_once('../../scripts/dbconnect.php');
session_start();

$result = mysqli_query($dbhandle, "SELECT * FROM flag");
while ($row = mysqli_fetch_assoc($result)) {
      echo $row["flag"]."<br>";
}


// if (!isset($_SESSION['username'])) {
	// header("Location: ../index.php");
// // }
// else {
// 	if ($usertype == 2) {
// }
// else {
// 	header("Location: ../index.php?msg=3");
// }

// }
// ?>