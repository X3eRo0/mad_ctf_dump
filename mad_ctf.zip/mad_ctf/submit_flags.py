from pwn import *

context.log_level = "critical"

host = "submit.alcapwnctf.in"
port = 31337

token = open("info.txt").read()

file = open("rootflag.txt").readlines()
flag = []

for i in range(len(file)):
    flag.append(file[i].split(":")[1].strip("\r\n"))

for i in range(len(flag)):
    print flag[i]
    p = remote(host, port)
    p.recvline()
    p.sendline(token)
    p.recvline()
    p.sendline(flag[i])
    response = p.recvline().strip()
    
    if "accepted" in response:
        print "[+] "+ response
    else:
        print "[-] " + response
    p.close()
