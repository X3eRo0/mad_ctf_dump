#include <stdio.h>
#include <string.h>

char* xorflag(char* flag){
    char *key ="\x01\x02\x03\x04\x05\x06\x07\x08\x09\x00";

    int j=0, i=0;
    for (i=0; i<32; i++){
        printf("%c", flag[i] ^ key[j]);
        if (j < 10){
            j++;
        }
    }
    puts("");
    return flag;
}

int main(){
    xorflag("EDOSMC_AQHES1JCXC4K8V45ANEIRIBI=");
    xorflag("EG6J\\I70A2XI884TFY11LI0M19KRHO0=");
    xorflag("EWBQ4SCC<4B3XJUPP3WCZI19NFI7D5Z=");
    
    return 0;
}