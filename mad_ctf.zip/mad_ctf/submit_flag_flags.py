from pwn import *
import requests

context.log_level = "critical"

host = "submit.alcapwnctf.in"
port = 31337

token = open("info.txt").read()
file = open("flag.txt", "r").readlines()

flags = []

for i in range(len(file)):
    flags.append("".join(file[i].split(":")).strip("\r\n"))

for i in flags:
#    print i
    try:
        i = i.split(":")[1]
    except:
        pass
    p = remote(host, port)
    p.recvline()
    p.sendline(token)
    p.recvline()
    p.sendline(i)
    response = p.recvline().strip()
    
    if "accepted" in response:
        print "[+] "+ response
    else:
        print "[-] " + response

    p.close()
